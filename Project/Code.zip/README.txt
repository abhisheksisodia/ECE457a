README

1. Open the algorithm_gui and run the gui in matlab
2. Set the Area parameters and Wind turbine type parameters
3. Select the algorithm which you want to run
4. Press run
5. The results will be displayed